# Haribo
비즈니스 모델링
