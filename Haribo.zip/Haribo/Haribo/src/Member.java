

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:44
 */
public class Member {

	public MemberInfo m_MemberInfo;

	public Member(){

	}

	public void finalize() throws Throwable {

	}

	public void subscribe(){

	}

}