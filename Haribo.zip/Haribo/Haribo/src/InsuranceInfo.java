

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:44
 */
public class InsuranceInfo {

	private float cancellationFeeRate;
	/**
	 * updateFrequency:�����ֱ�
	 * expiration:����Ⱓ
	 * cancellationFeeRate:�ߵ��ؾ���غ���
	 */
	private int expiration;
	private int updateFrequency;

	public InsuranceInfo(){

	}

	public void finalize() throws Throwable {

	}

	public int getExpiration() {
		return expiration;
	}

	public void setExpiration(int expiration) {
		this.expiration = expiration;
	}

	public int getUpdateFrequency() {
		return updateFrequency;
	}

	public void setUpdateFrequency(int updateFrequency) {
		this.updateFrequency = updateFrequency;
	}

	public float getCancellationFeeRate() {
		return cancellationFeeRate;
	}

	public void setCancellationFeeRate(float cancellationFeeRate) {
		this.cancellationFeeRate = cancellationFeeRate;
	}

}