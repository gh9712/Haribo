

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:45
 */
public class RewardProcessor {

	public Insurance m_Insurance;

	public RewardProcessor(){

	}

	public void finalize() throws Throwable {

	}

	public void choose(){

	}

	public void evaluate(){

	}

	public void write(){

	}

}