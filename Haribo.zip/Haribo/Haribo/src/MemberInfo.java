

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:44
 */
public class MemberInfo {

	private int accountNumber;
	private String address;
	private int age;
	private String email;
	private boolean gender;
	private enum job{};
	private enum medicalHistory{};
	private String name;
	private int phoneNumber;
	private int registrationNumber;

	public void MemberInfo(){

	}

	public void finalize() throws Throwable {

	}

}