

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:43
 */
public class CarInsurance extends Insurance {

	private int accidentInsuranceFee;
	private int accidentLevel;
	private boolean car;
	private int carAge;
	private String carType;
	private boolean children;
	private float faultRate;
	private int injuryMedicalExpenses;
	private int insuranceTerm;
	private int selfFee;

	public CarInsurance(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public void getInfo(){

	}

	public int getAccidentInsuranceFee() {
		return accidentInsuranceFee;
	}

	public void setAccidentInsuranceFee(int accidentInsuranceFee) {
		this.accidentInsuranceFee = accidentInsuranceFee;
	}

	public int getAccidentLevel() {
		return accidentLevel;
	}

	public void setAccidentLevel(int accidentLevel) {
		this.accidentLevel = accidentLevel;
	}

	public boolean isCar() {
		return car;
	}

	public void setCar(boolean car) {
		this.car = car;
	}

	public int getCarAge() {
		return carAge;
	}

	public void setCarAge(int carAge) {
		this.carAge = carAge;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public boolean isChildren() {
		return children;
	}

	public void setChildren(boolean children) {
		this.children = children;
	}

	public float getFaultRate() {
		return faultRate;
	}

	public void setFaultRate(float faultRate) {
		this.faultRate = faultRate;
	}

	public int getInjuryMedicalExpenses() {
		return injuryMedicalExpenses;
	}

	public void setInjuryMedicalExpenses(int injuryMedicalExpenses) {
		this.injuryMedicalExpenses = injuryMedicalExpenses;
	}

	public int getInsuranceTerm() {
		return insuranceTerm;
	}

	public void setInsuranceTerm(int insuranceTerm) {
		this.insuranceTerm = insuranceTerm;
	}

	public int getSelfFee() {
		return selfFee;
	}

	public void setSelfFee(int selfFee) {
		this.selfFee = selfFee;
	}

}