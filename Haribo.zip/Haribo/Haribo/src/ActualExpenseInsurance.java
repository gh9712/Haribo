

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:43
 */
public class ActualExpenseInsurance extends Insurance {

	private int diseaseMedicalExpenses;
	private int injuryMedicalExpenses;
	private int insuranceTerm;
	private int selfFee;
	private int updateFrequency;

	public ActualExpenseInsurance(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public void getInfo(){

	}

	public int getDiseaseMedicalExpenses() {
		return diseaseMedicalExpenses;
	}

	public void setDiseaseMedicalExpenses(int diseaseMedicalExpenses) {
		this.diseaseMedicalExpenses = diseaseMedicalExpenses;
	}

	public int getInjuryMedicalExpenses() {
		return injuryMedicalExpenses;
	}

	public void setInjuryMedicalExpenses(int injuryMedicalExpenses) {
		this.injuryMedicalExpenses = injuryMedicalExpenses;
	}

	public int getInsuranceTerm() {
		return insuranceTerm;
	}

	public void setInsuranceTerm(int insuranceTerm) {
		this.insuranceTerm = insuranceTerm;
	}

	public int getSelfFee() {
		return selfFee;
	}

	public void setSelfFee(int selfFee) {
		this.selfFee = selfFee;
	}

	public int getUpdateFrequency() {
		return updateFrequency;
	}

	public void setUpdateFrequency(int updateFrequency) {
		this.updateFrequency = updateFrequency;
	}

}