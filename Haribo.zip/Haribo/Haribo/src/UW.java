

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:45
 */
public class UW {

	public Insurance m_Insurance;

	public UW(){

	}

	public void finalize() throws Throwable {

	}

	public void choose(){

	}

	public void confirm(){

	}

}