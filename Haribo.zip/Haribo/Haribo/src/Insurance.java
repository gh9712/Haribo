

/**
 * ����
 * ����� = (����� * Ȯ�� * 1.1) / (����Ⱓ(��) * 12)
 * Ȯ���� ���� ���� ������ ���¿� ���� Ȯ���� ���Ƿ� ����Ͽ� ���Ѵ�.
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:44
 */
public class Insurance {

	private String description;
	private int fee;
	private int ID;
	private String Name;
	public InsuranceInfo m_InsuranceInfo;
	public InsuranceFeeInfo m_InsuranceFeeInfo;
	public Member m_Member;

	public Insurance(){

	}

	public void finalize() throws Throwable {

	}

	/**
	 * 
	 * @param UserInfo
	 */
	public void calculator(MemberInfo memberInfo){

	}

	/**
	 * 
	 * @param userInfo
	 */
	public void call(MemberInfo memberInfo){

	}

	public int getID(){
		return 0;
	}

	public void predict(){

	}

	/**
	 * 
	 * @param Description
	 */
	public void setDescription(String Description){

	}

	/**
	 * 
	 * @param id
	 */
	public void setID(int id){

	}

	/**
	 * 
	 * @param name
	 */


	public void sort(){

	}

	public int getFee() {
		return fee;
	}

	public void setFee(int fee) {
		this.fee = fee;
	}

	public void setm_InsuranceInfo(){
		
	}
	public void getm_InsuranceInfo(){
		
	}
	
	public void setm_InsuranceFeeInfo(){
		
	}
	public void getm_InsuranceFeeInfo(){
		
	}
	public void setm_Member(){
		
	}
	public void getm_Member(){
		
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
}