

/**
 * <���� ���>
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:44
 */
public class InjuryInsurance extends Insurance {

	private int accidentMedicalExpenses;
	private int diseaseMedicalExpenses;
	private int injuryLevel;
	private int insuranceTerm;
	private int selfFee;

	public InjuryInsurance(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public void getInfo(){

	}

	public int getDiseaseMedicalExpenses() {
		return diseaseMedicalExpenses;
	}

	public void setDiseaseMedicalExpenses(int diseaseMedicalExpenses) {
		this.diseaseMedicalExpenses = diseaseMedicalExpenses;
	}

	public int getAccidentMedicalExpenses() {
		return accidentMedicalExpenses;
	}

	public void setAccidentMedicalExpenses(int accidentMedicalExpenses) {
		this.accidentMedicalExpenses = accidentMedicalExpenses;
	}

	public int getInjuryLevel() {
		return injuryLevel;
	}

	public void setInjuryLevel(int injuryLevel) {
		this.injuryLevel = injuryLevel;
	}

	public int getInsuranceTerm() {
		return insuranceTerm;
	}

	public void setInsuranceTerm(int insuranceTerm) {
		this.insuranceTerm = insuranceTerm;
	}

	public int getSelfFee() {
		return selfFee;
	}

	public void setSelfFee(int selfFee) {
		this.selfFee = selfFee;
	}

}