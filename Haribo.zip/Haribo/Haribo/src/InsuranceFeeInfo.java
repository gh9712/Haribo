

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:44
 */
public class InsuranceFeeInfo {

	private int cancellationRefund;
	private int payment;
	private int paymentPeriod;
	/**
	 * paymentTerm:���ԱⰣ
	 * paymentPeriod:�����ֱ�
	 */
	private int paymentTerm;
	private int subscribeFee;

	public InsuranceFeeInfo(){

	}

	public void finalize() throws Throwable {

	}

	public int getCancellationRefund() {
		return cancellationRefund;
	}

	public void setCancellationRefund(int cancellationRefund) {
		this.cancellationRefund = cancellationRefund;
	}

	public int getPayment() {
		return payment;
	}

	public void setPayment(int payment) {
		this.payment = payment;
	}

	public int getPaymentPeriod() {
		return paymentPeriod;
	}

	public void setPaymentPeriod(int paymentPeriod) {
		this.paymentPeriod = paymentPeriod;
	}

	public int getPaymentTerm() {
		return paymentTerm;
	}

	public void setPaymentTerm(int paymentTerm) {
		this.paymentTerm = paymentTerm;
	}

	public int getSubscribeFee() {
		return subscribeFee;
	}

	public void setSubscribeFee(int subscribeFee) {
		this.subscribeFee = subscribeFee;
	}

}