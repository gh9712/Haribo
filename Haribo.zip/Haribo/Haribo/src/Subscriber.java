

/**
 * @author gh971
 * @version 1.0
 * @created 28-4-2017 ���� 11:08:45
 */
public class Subscriber {

	private String name;

	public Subscriber(){

	}

	public void finalize() throws Throwable {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



}